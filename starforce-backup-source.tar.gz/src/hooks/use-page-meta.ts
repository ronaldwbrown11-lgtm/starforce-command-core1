import { useEffect } from "react";

/**
 * Sets document.title and the social/meta tags for the current page so
 * shared links preview nicely (OG + Twitter cards). Falls back to the
 * index.html defaults for values that aren't provided.
 */
export function usePageMeta({
  title,
  description,
  image,
}: {
  title: string;
  description?: string;
  image?: string | null;
}) {
  useEffect(() => {
    document.title = title;

    function upsert(attr: "name" | "property", key: string, content: string) {
      let el = document.head.querySelector<HTMLMetaElement>(
        `meta[${attr}="${key}"]`,
      );
      if (!el) {
        el = document.createElement("meta");
        el.setAttribute(attr, key);
        document.head.appendChild(el);
      }
      el.setAttribute("content", content);
    }

    const url = window.location.href;
    upsert("property", "og:title", title);
    upsert("name", "twitter:title", title);
    upsert("property", "og:url", url);
    upsert("name", "twitter:url", url);
    if (description) {
      upsert("name", "description", description);
      upsert("property", "og:description", description);
      upsert("name", "twitter:description", description);
    }
    if (image) {
      upsert("property", "og:image", image);
      upsert("name", "twitter:image", image);
    }
  }, [title, description, image]);
}
