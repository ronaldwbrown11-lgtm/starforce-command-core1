import { mutation, query } from "./_generated/server";
import type { MutationCtx } from "./_generated/server";
import { v, type Infer } from "convex/values";
import { requireOperatorCapability } from "./admin";
import type { Id } from "./_generated/dataModel";

// =========================================================================
// Assets — Convex file storage for cover plates on story / lore / transmission.
// Operator-gated uploads with size + MIME guards, audit logging, and orphan
// cleanup when a row's cover is replaced or removed.
// =========================================================================

export const COVER_MAX_BYTES = 5 * 1024 * 1024;
export const COVER_MIME_TYPES = [
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/avif",
] as const;

const coverMetaValidator = v.object({
  mimeType: v.string(),
  byteSize: v.number(),
  width: v.optional(v.number()),
  height: v.optional(v.number()),
  altText: v.optional(v.string()),
});
export type CoverMeta = Infer<typeof coverMetaValidator>;

function validateCoverMeta(meta: CoverMeta) {
  if (meta.byteSize > COVER_MAX_BYTES) {
    throw new Error(
      `Image too large (${(meta.byteSize / (1024 * 1024)).toFixed(1)} MB; max ${COVER_MAX_BYTES / (1024 * 1024)} MB).`,
    );
  }
  if (!(COVER_MIME_TYPES as readonly string[]).includes(meta.mimeType)) {
    throw new Error(
      `Unsupported image type (${meta.mimeType}). Allowed: ${COVER_MIME_TYPES.join(", ")}.`,
    );
  }
}

// ---- Upload URL generator ----

export const generateUploadUrl = mutation({
  args: { purpose: v.optional(v.string()) },
  handler: async (ctx, args) => {
    const { me } = await requireOperatorCapability(ctx, [
      "operator",
      "senior_operator",
      "story_editor",
      "lore_archivist",
    ]);
    const url = await ctx.storage.generateUploadUrl();
    await ctx.db.insert("auditLog", {
      actorId: me,
      action: args.purpose
        ? `assets.generate_url.${args.purpose}`
        : "assets.generate_url",
      target: "storage",
      createdAt: Date.now(),
    });
    return url;
  },
});

// ---- Standalone URL resolver ----

export const coverUrl = query({
  args: { storageId: v.id("_storage") },
  handler: async (ctx, args) => {
    return await ctx.storage.getUrl(args.storageId);
  },
});

// ---- Shared attach + remove helpers (DRY across the 3 entities) ----

async function attachCoverInternal(
  ctx: MutationCtx,
  table: "stories" | "loreEntries" | "transmissions",
  id: Id<"stories"> | Id<"loreEntries"> | Id<"transmissions">,
  storageId: Id<"_storage">,
  meta: CoverMeta,
  auditActionBase: string,
) {
  const { me } = await requireOperatorCapability(ctx, [
    "operator",
    "senior_operator",
  ]);
  validateCoverMeta(meta);
  const existing = await ctx.db.get(id);
  if (!existing) throw new Error("Not found.");
  const priorStorageId = existing.coverStorageId;
  await ctx.db.patch(id, {
    coverStorageId: storageId,
    coverMeta: meta,
  });
  if (priorStorageId && priorStorageId !== storageId) {
    try {
      await ctx.storage.delete(priorStorageId);
    } catch {
      // Orphan deletion failures are non-fatal — the row update already landed.
    }
  }
  await ctx.db.insert("auditLog", {
    actorId: me,
    action: `${auditActionBase}.cover_attach`,
    target: `${table}:${id}`,
    meta: JSON.stringify({ mimeType: meta.mimeType, byteSize: meta.byteSize }),
    createdAt: Date.now(),
  });
  return { ok: true };
}

async function removeCoverInternal(
  ctx: MutationCtx,
  table: "stories" | "loreEntries" | "transmissions",
  id: Id<"stories"> | Id<"loreEntries"> | Id<"transmissions">,
  auditActionBase: string,
) {
  const { me } = await requireOperatorCapability(ctx, [
    "operator",
    "senior_operator",
  ]);
  const existing = await ctx.db.get(id);
  if (!existing) throw new Error("Not found.");
  const priorStorageId = existing.coverStorageId;
  await ctx.db.patch(id, {
    coverStorageId: undefined,
    coverMeta: undefined,
  });
  if (priorStorageId) {
    try {
      await ctx.storage.delete(priorStorageId);
    } catch {
      // ignore
    }
  }
  await ctx.db.insert("auditLog", {
    actorId: me,
    action: `${auditActionBase}.cover_remove`,
    target: `${table}:${id}`,
    createdAt: Date.now(),
  });
  return { ok: true };
}

// ---- Story covers (story_editor permitted) ----

export const attachStoryCover = mutation({
  args: {
    id: v.id("stories"),
    storageId: v.id("_storage"),
    meta: coverMetaValidator,
  },
  handler: async (ctx, args) => {
    const { me } = await requireOperatorCapability(ctx, [
      "operator",
      "senior_operator",
      "story_editor",
    ]);
    validateCoverMeta(args.meta);
    const existing = await ctx.db.get(args.id);
    if (!existing) throw new Error("Story not found.");
    const priorStorageId = existing.coverStorageId;
    await ctx.db.patch(args.id, {
      coverStorageId: args.storageId,
      coverMeta: args.meta,
    });
    if (priorStorageId && priorStorageId !== args.storageId) {
      try {
        await ctx.storage.delete(priorStorageId);
      } catch {
        // ignore
      }
    }
    await ctx.db.insert("auditLog", {
      actorId: me,
      action: "story.cover_attach",
      target: `story:${args.id}`,
      meta: JSON.stringify({
        mimeType: args.meta.mimeType,
        byteSize: args.meta.byteSize,
      }),
      createdAt: Date.now(),
    });
    return { ok: true };
  },
});

export const removeStoryCover = mutation({
  args: { id: v.id("stories") },
  handler: async (ctx, args) =>
    removeCoverInternal(ctx, "stories", args.id, "story"),
});

// ---- Lore covers (lore_archivist permitted) ----

export const attachLoreCover = mutation({
  args: {
    id: v.id("loreEntries"),
    storageId: v.id("_storage"),
    meta: coverMetaValidator,
  },
  handler: async (ctx, args) => {
    const { me } = await requireOperatorCapability(ctx, [
      "operator",
      "senior_operator",
      "lore_archivist",
    ]);
    validateCoverMeta(args.meta);
    const existing = await ctx.db.get(args.id);
    if (!existing) throw new Error("Lore entry not found.");
    const priorStorageId = existing.coverStorageId;
    await ctx.db.patch(args.id, {
      coverStorageId: args.storageId,
      coverMeta: args.meta,
    });
    if (priorStorageId && priorStorageId !== args.storageId) {
      try {
        await ctx.storage.delete(priorStorageId);
      } catch {
        // ignore
      }
    }
    await ctx.db.insert("auditLog", {
      actorId: me,
      action: "lore.cover_attach",
      target: `lore:${args.id}`,
      meta: JSON.stringify({
        mimeType: args.meta.mimeType,
        byteSize: args.meta.byteSize,
      }),
      createdAt: Date.now(),
    });
    return { ok: true };
  },
});

export const removeLoreCover = mutation({
  args: { id: v.id("loreEntries") },
  handler: async (ctx, args) =>
    removeCoverInternal(ctx, "loreEntries", args.id, "lore"),
});

// ---- Transmission covers (operator only) ----

export const attachTransmissionCover = mutation({
  args: {
    id: v.id("transmissions"),
    storageId: v.id("_storage"),
    meta: coverMetaValidator,
  },
  handler: async (ctx, args) => {
    const { me } = await requireOperatorCapability(ctx, [
      "operator",
      "senior_operator",
    ]);
    validateCoverMeta(args.meta);
    const existing = await ctx.db.get(args.id);
    if (!existing) throw new Error("Transmission not found.");
    const priorStorageId = existing.coverStorageId;
    await ctx.db.patch(args.id, {
      coverStorageId: args.storageId,
      coverMeta: args.meta,
    });
    if (priorStorageId && priorStorageId !== args.storageId) {
      try {
        await ctx.storage.delete(priorStorageId);
      } catch {
        // ignore
      }
    }
    await ctx.db.insert("auditLog", {
      actorId: me,
      action: "transmission.cover_attach",
      target: `transmission:${args.id}`,
      meta: JSON.stringify({
        mimeType: args.meta.mimeType,
        byteSize: args.meta.byteSize,
      }),
      createdAt: Date.now(),
    });
    return { ok: true };
  },
});

export const removeTransmissionCover = mutation({
  args: { id: v.id("transmissions") },
  handler: async (ctx, args) =>
    removeCoverInternal(ctx, "transmissions", args.id, "transmission"),
});
