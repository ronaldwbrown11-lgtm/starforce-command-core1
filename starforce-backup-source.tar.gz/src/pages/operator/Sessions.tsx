import { useMutation, useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { useState } from "react";
import { OperatorShell } from "@/components/operator/OperatorShell";
import { HoloCard, NeonButton, StatusPill } from "@/components/uf";
import { toast } from "sonner";

export default function OperatorSessions() {
  const items = useQuery(api.operator.listSessions, { limit: 50 });
  const revoke = useMutation(api.operator.revokeSession);
  const trust = useMutation(api.operator.trustSession);
  const [pending, setPending] = useState<string | null>(null);
  return (
    <OperatorShell>
      <header className="mb-6">
        <span className="uf-eyebrow">Operator Console</span>
        <h1 className="text-3xl font-semibold mt-2">Sessions</h1>
        <p className="text-uf-muted text-sm mt-1">Revoke or mark trusted. Audit logged.</p>
      </header>
      {items === undefined ? (
        <div className="uf-skeleton" style={{ height: 200 }} />
      ) : items.length === 0 ? (
        <HoloCard>
          <div className="uf-empty">No active sessions.</div>
        </HoloCard>
      ) : (
        <HoloCard>
          <table className="uf-data-grid">
            <caption className="uf-sr-only">Active sessions</caption>
            <thead>
              <tr>
                <th>User ID</th>
                <th>Session</th>
                <th>IP</th>
                <th>UA</th>
                <th>Login</th>
                <th>Trust</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {items.map((s) => (
                <tr key={s._id}>
                  <td>{(s.userId as string).slice(0, 10)}…</td>
                  <td>{(s.sessionToken as string).slice(0, 10)}…</td>
                  <td>{s.ip}</td>
                  <td className="max-w-32 truncate">{s.ua}</td>
                  <td>{new Date(s.loginAt).toLocaleString()}</td>
                  <td>
                    <StatusPill variant={s.trust ? "success" : "default"}>
                      {s.trust ? "Trusted" : "Untrusted"}
                    </StatusPill>
                  </td>
                  <td>
                    <div className="flex flex-wrap gap-2">
                      <NeonButton
                        variant="primary"
                        disabled={pending === s._id}
                        onClick={async () => {
                          setPending(s._id);
                          try {
                            await trust({ id: s._id, trust: !s.trust });
                            toast.success("Trust updated.");
                          } catch {
                            toast.error("Forbidden.");
                          } finally {
                            setPending(null);
                          }
                        }}
                      >
                        {s.trust ? "Untrust" : "Trust"}
                      </NeonButton>
                      <NeonButton
                        variant="danger"
                        disabled={pending === s._id}
                        onClick={async () => {
                          if (!window.confirm("Revoke this session? Audit-logged.")) return;
                          setPending(s._id);
                          try {
                            await revoke({ id: s._id });
                            toast.success("Session revoked.");
                          } catch {
                            toast.error("Forbidden.");
                          } finally {
                            setPending(null);
                          }
                        }}
                      >
                        Revoke
                      </NeonButton>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </HoloCard>
      )}
    </OperatorShell>
  );
}
