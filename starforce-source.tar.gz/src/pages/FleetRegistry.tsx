import { useMemo, useState } from "react";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { SiteShell, PageHero, HoloCard, StatusPill } from "@/components/uf";
import { ScrollReveal, ScaleReveal } from "@/hooks/use-scroll-reveal";
import { usePageMeta } from "@/hooks/use-page-meta";
import { Search, Shield, Anchor, Rocket, Crosshair, Eye, Ship, Stethoscope, Wrench, AlertTriangle } from "lucide-react";

const BADGE_ICONS: Record<string, typeof Shield> = {
  CARRIER: Ship, DREADNAUGHT: Shield, DESTROYER: Crosshair, BATTLESHIP: Shield,
  FLAGSHIP: Anchor, TRANSPORT: Rocket, ESCORT: Shield, SUPPRESSION: AlertTriangle,
  DRONE: Eye, STEALTH: Eye, MEDICAL: Stethoscope, INDUSTRIAL: Wrench, STRIKE: Crosshair,
  INTERCEPTOR: Rocket, FIGHTER: Rocket, CORVETTE: Ship, FRIGATE: Ship,
};

function VesselCard({ vessel }: { vessel: any }) {
  const Icon = BADGE_ICONS[vessel.badge] ?? Ship;
  return (
    <ScaleReveal>
      <HoloCard className="h-full">
        <div className="flex items-start gap-3 mb-3">
          <span className="h-10 w-10 rounded-md flex items-center justify-center shrink-0"
            style={{ color: "var(--uf-cyan)", border: "1px solid rgba(0,229,255,0.35)", background: "rgba(0,229,255,0.08)" }}>
            <Icon className="h-5 w-5" />
          </span>
          <div className="min-w-0">
            <h3 className="text-base font-semibold text-uf-text truncate">{vessel.name}</h3>
            <p className="text-xs text-uf-muted font-mono">{vessel.designation}</p>
          </div>
          <StatusPill variant="info" className="ml-auto shrink-0">{vessel.badge}</StatusPill>
        </div>
        {vessel.shipClass ? <p className="text-xs text-[var(--uf-cyan)] mb-1">{vessel.shipClass}</p> : null}
        <p className="text-sm text-uf-muted mb-3 leading-relaxed">{vessel.role}</p>
        <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs border-t border-[color:var(--uf-border)] pt-3">
          {vessel.registry ? <div><span className="text-uf-muted">Registry:</span> <span className="text-uf-text font-mono">{vessel.registry}</span></div> : null}
          {vessel.crew ? <div><span className="text-uf-muted">Crew:</span> <span className="text-uf-text">{vessel.crew}</span></div> : null}
          {vessel.hullLength ? <div><span className="text-uf-muted">Length:</span> <span className="text-uf-text">{vessel.hullLength}m</span></div> : null}
          {vessel.decks ? <div><span className="text-uf-muted">Decks:</span> <span className="text-uf-text">{vessel.decks}</span></div> : null}
          {vessel.weight ? <div><span className="text-uf-muted">Mass:</span> <span className="text-uf-text">{vessel.weight}</span></div> : null}
          {vessel.acceleration ? <div className="col-span-2"><span className="text-uf-muted">Drive:</span> <span className="text-uf-text">{vessel.acceleration}</span></div> : null}
        </div>
        {vessel.armament ? (
          <div className="mt-3 text-xs border-t border-[color:var(--uf-border)] pt-3">
            <span className="text-uf-muted">Armament:</span> <span className="text-uf-text">{vessel.armament}</span>
          </div>
        ) : null}
        {vessel.notes ? (
          <div className="mt-2 text-xs text-uf-muted italic">{vessel.notes}</div>
        ) : null}
      </HoloCard>
    </ScaleReveal>
  );
}

export default function FleetRegistry() {
  const [search, setSearch] = useState("");
  const [badgeFilter, setBadgeFilter] = useState("");
  const vessels = useQuery(api.vessels.listAll);
  const vesselStats = useQuery(api.vessels.stats);

  usePageMeta({
    title: "Star Force Fleet Registry — Star Force Base 1198",
    description: "The official registry of every vessel commissioned by the Star Force. Designation, specifications, armament, and operational history.",
    jsonLd: {
      "@type": "CollectionPage",
      name: "Star Force Fleet Registry",
      description: "Official registry of commissioned Star Force vessels.",
    },
  });

  const badges = useMemo(() => {
    if (!vessels) return [];
    const set = new Set(vessels.map((v) => v.badge));
    return ["", ...Array.from(set).sort()];
  }, [vessels]);

  const filtered = useMemo(() => {
    if (!vessels) return undefined;
    let list = vessels;
    if (badgeFilter) list = list.filter((v) => v.badge === badgeFilter);
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(
        (v) =>
          v.designation.toLowerCase().includes(q) ||
          v.name.toLowerCase().includes(q) ||
          v.role.toLowerCase().includes(q) ||
          (v.shipClass ?? "").toLowerCase().includes(q) ||
          (v.registry ?? "").toLowerCase().includes(q),
      );
    }
    return list;
  }, [vessels, search, badgeFilter]);

  return (
    <SiteShell bgPalette="sapphire">
      <PageHero
        eyebrow="Fleet Registry"
        title="The Official Registry of Star Force Vessels"
        lead="Every vessel commissioned by the Star Force — designation, specifications, armament, and operational history. Maintained by the Department of Fleet Records."
      />

      <section className="uf-section max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-12">
        {/* Stats strip */}
        {vesselStats && (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-px border border-white/10 bg-white/10 mb-8">
            <div className="bg-[rgba(5,8,22,0.85)] px-6 py-4 text-center">
              <p className="text-2xl font-semibold">{vesselStats.total}</p>
              <p className="text-xs text-uf-muted uppercase tracking-wider">Vessels Registered</p>
            </div>
            {Object.entries(vesselStats.byBadge).slice(0, 3).map(([badge, count]) => (
              <div key={badge} className="bg-[rgba(5,8,22,0.85)] px-6 py-4 text-center">
                <p className="text-2xl font-semibold">{count}</p>
                <p className="text-xs text-uf-muted uppercase tracking-wider">{badge}</p>
              </div>
            ))}
          </div>
        )}

        {/* Search + filter */}
        <div className="flex flex-col sm:flex-row gap-3 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-uf-muted" />
            <input
              type="text" value={search} onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by designation, name, class, or role…"
              className="w-full pl-10 pr-4 py-2.5 rounded-lg border border-[color:var(--uf-border)] bg-[rgba(5,8,22,0.6)] text-sm text-uf-text placeholder:text-uf-muted/60 focus:border-[rgba(0,229,255,0.5)] focus:outline-none"
            />
          </div>
          <nav className="flex flex-wrap gap-2" aria-label="Filter by class">
            {badges.map((b) => (
              <button key={b || "all"} onClick={() => setBadgeFilter(b)}
                className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors cursor-pointer ${
                  badgeFilter === b
                    ? "bg-[rgba(0,229,255,0.15)] text-[var(--uf-cyan)] border border-[rgba(0,229,255,0.4)]"
                    : "bg-[rgba(255,255,255,0.04)] text-uf-muted border border-[color:var(--uf-border)] hover:text-uf-text"
                }`}>
                {b || "All"}
              </button>
            ))}
          </nav>
        </div>

        {/* Vessel grid */}
        {filtered === undefined ? (
          <div className="uf-grid uf-grid--3">
            {[1, 2, 3, 4, 5, 6].map((i) => <div key={i} className="uf-skeleton" style={{ height: 280 }} />)}
          </div>
        ) : filtered.length === 0 ? (
          <HoloCard><div className="uf-empty"><Ship className="h-8 w-8 mx-auto mb-3 opacity-40" /><p>No vessels match your search.</p></div></HoloCard>
        ) : (
          <div className="uf-grid uf-grid--3">
            {filtered.map((vessel) => (
              <VesselCard key={vessel._id} vessel={vessel} />
            ))}
          </div>
        )}
      </section>
    </SiteShell>
  );
}
