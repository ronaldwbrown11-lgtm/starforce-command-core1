import { useState, useMemo } from "react";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Link } from "react-router";
import { SiteShell, PageHero, NeonButton, HoloCard, StatusPill } from "@/components/uf";
import { ScrollReveal, ScaleReveal } from "@/hooks/use-scroll-reveal";
import { TrendingTags } from "@/components/widgets/TrendingTags";
import { usePageMeta } from "@/hooks/use-page-meta";

export default function Stories() {
  const [search, setSearch] = useState("");
  usePageMeta({
    title: "Stories — Star Force Base 1198",
    description: "Read the latest sci-fi stories, series, and flash fiction from the Star Force community. Canon submissions reviewed by fleet operators.",
    jsonLd: { "@type": "CollectionPage", name: "Star Force Stories", description: "Sci-fi stories from the Star Force community." },
  });
  const [filterFaction, setFilterFaction] = useState("");
  const stories = useQuery(api.content.listStories, { limit: 50 });

  const filtered = useMemo(() => {
    if (!stories) return undefined;
    return stories.filter((s) => {
      const sText =
        (s.title + " " + s.excerpt + " " + (s.tags ?? []).join(" ")).toLowerCase();
      if (search && !sText.includes(search.toLowerCase())) return false;
      if (filterFaction && !(s.factions ?? []).includes(filterFaction)) return false;
      return true;
    });
  }, [stories, search, filterFaction]);

  return (
    <SiteShell bgPalette="amber-magenta">
      <PageHero
        eyebrow="The Starforce Files"
        title="Transmissions from the Fleet"
        lead="Stories contributed by members, reviewed by editors, organized in series."
        primary={{ label: "Continue Mission", href: "/community", variant: "primary" }}
        secondary={{ label: "Submit Story", href: "/submit", variant: "ghost" }}
      />
      <section className="uf-section max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-12">
        <div className="grid md:grid-cols-3 gap-3 mb-6">
          <label className="text-xs uppercase tracking-[0.16em] text-uf-muted flex flex-col gap-1">
            Search
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="search the archive…"
              className="border border-[color:var(--uf-border)] rounded-md px-3 py-2 text-sm bg-[rgba(16,24,39,0.5)]"
            />
          </label>
          <label className="text-xs uppercase tracking-[0.16em] text-uf-muted flex flex-col gap-1">
            Filter by faction
            <input
              value={filterFaction}
              onChange={(e) => setFilterFaction(e.target.value)}
              placeholder="e.g., Terran Reach"
              className="border border-[color:var(--uf-border)] rounded-md px-3 py-2 text-sm bg-[rgba(16,24,39,0.5)]"
            />
          </label>
          <div className="text-xs uppercase tracking-[0.16em] text-uf-muted flex items-end">
            <TrendingTags limit={8} />
          </div>
        </div>
        <div role="status" aria-live="polite" className="text-uf-muted text-xs mb-3">
          {filtered === undefined
            ? "Synchronizing with the fleet archive…"
            : `${filtered.length} transmissions${search ? ` matching “${search}”` : ""}.`}
        </div>
        {filtered === undefined ? (
          <>
            <div className="uf-grid uf-grid--3">
              {[0, 1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="uf-skeleton" style={{ height: 200 }} />
              ))}
            </div>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="uf-btn uf-btn--ghost mt-4"
            >
              ⟳ Signal weak — retry sync
            </button>
          </>
        ) : filtered.length === 0 ? (
          <div className="uf-empty">
            {search || filterFaction
              ? "No transmissions match these filters yet."
              : "The archive is empty — be the first to transmit."}
          </div>
        ) : (
          <div className="uf-grid uf-grid--3">
            {filtered.map((s, idx) => (
              <Link key={s._id} to={`/stories/${s.slug}`} className="block">
                <ScaleReveal staggerIndex={idx}>
                <HoloCard>
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <StatusPill variant="info">
                      {s.series ?? "Standalone"}
                    </StatusPill>
                    {s.readMinutes && (
                      <StatusPill variant="default">~{s.readMinutes} min</StatusPill>
                    )}
                  </div>
                  <h3 className="text-xl font-semibold">{s.title}</h3>
                  <p className="text-uf-muted text-sm mt-2">{s.excerpt}</p>
                  <div className="flex flex-wrap gap-2 mt-3">
                    {(s.factions ?? []).slice(0, 2).map((f) => (
                      <StatusPill key={f} variant="info">
                        {f}
                      </StatusPill>
                    ))}
                    {s.classification && (
                      <StatusPill variant="warning">{s.classification}</StatusPill>
                    )}
                  </div>
                  <span className="uf-btn uf-btn--ghost mt-4">
                    Continue Mission
                  </span>
                </HoloCard>
              </ScaleReveal>
              </Link>
            ))}
          </div>
        )}
      </section>
    </SiteShell>
  );
}
