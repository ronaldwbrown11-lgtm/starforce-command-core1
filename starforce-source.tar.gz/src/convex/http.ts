import { httpRouter } from "convex/server";
import { auth } from "./auth";
import { stripeWebhook } from "./stripeWebhook";
import { generateSitemap } from "./sitemap";

const http = httpRouter();

auth.addHttpRoutes(http);

// Stripe membership fulfillment — see https://dashboard.stripe.com/webhooks
http.route({
  path: "/stripe-webhook",
  method: "POST",
  handler: stripeWebhook,
});

// Live sitemap.xml — generated from database content
http.route({
  path: "/sitemap.xml",
  method: "GET",
  handler: generateSitemap,
});

export default http;
